/*
TODO: for fonts
- auto font selection (how does this work??)
- manual font selection
	- dropdown in settings?
- font upload (how store??? and how many)
	- the easy way is to start with one
- how are fonts stored in the game export?
	 - BDF text file and then loaded at game start? or some in-code representation?
- how are fonts called out in the game data?
	 - store font name in the file so at least people know what it wants.. even if it doesn't exist
- X bitsy to BDF
- sprite glyphs (custom-size characters?? or double wide characters??)
	- exception to rule
	- shortens the row its on so characters don't go over the edge
	- do anything about height???
*/


function Font(fontName) {

var width = 6;
var height = 8;

var fontdata = {};

this.getData = function() {
	return fontdata;
}

this.getWidth = function() {
	return width;
}

this.getHeight = function() {
	return height;
}

var charSize = 6 * 8;
this.getChar = function(char) {

	var codepoint = char.charCodeAt(0);

	if (fontdata[codepoint] != null) {
		return fontdata[codepoint];
	}
	else {
		var invalidCharData = [];
		for (var i = 0; i < width*height; i++)
			invalidCharData.push(1);
		return invalidCharData;
	}
}


// do I even want to commit to the BDF font format??
// I could create my OWN font format with overwritable characters...
// if so would I store it in the main game data or not???
function loadBDF(bdfText) {
	fontdata = {};

	var lines = bdfText.split("\n");

	var codePoint = 0;
	var isReadingBitmap = false;
	var bitList = [];

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i];

		if (line.indexOf("FONTBOUNDINGBOX") != -1) {
			width = parseInt( line.split(" ")[1] );
			height = parseInt( line.split(" ")[2] );
		}

		if (line.indexOf("ENCODING") != -1) {
			codePoint = parseInt( line.split(" ")[1] );
		}

		if (line.indexOf("ENDCHAR") != -1) {
			isReadingBitmap = false;
			// console.log("----");
			fontdata[codePoint] = bitList;
		}

		if (isReadingBitmap) {
			var hexInt = parseInt("0x" + line);
			
			for (var j = (width-1); j >= 0; j--) {
				var bit = (hexInt >> j + 2) & 1; // was +2
				bitList.push( bit );
			}
		}

		if (line.indexOf("BITMAP") != -1) {
			isReadingBitmap = true;
			bitList = [];
		}
	}
}

console.log("!!!!!! " + fontName);
var bdfText = document.getElementById(fontName).text.slice(1);
loadBDF(bdfText);

} // Font()